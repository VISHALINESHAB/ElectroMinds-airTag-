#ifndef EEZ_LVGL_UI_VARS_H
#define EEZ_LVGL_UI_VARS_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

// enum declarations



// Flow global variables

enum FlowGlobalVariables {
    FLOW_GLOBAL_VARIABLE_MESSAGE_1 = 0,
    FLOW_GLOBAL_VARIABLE_TIME_REMAINING = 1,
    FLOW_GLOBAL_VARIABLE_HOURS = 2,
    FLOW_GLOBAL_VARIABLE_MINUTES = 3,
    FLOW_GLOBAL_VARIABLE_SOC = 4
};

// Native global variables



#ifdef __cplusplus
}
#endif

#endif /*EEZ_LVGL_UI_VARS_H*/