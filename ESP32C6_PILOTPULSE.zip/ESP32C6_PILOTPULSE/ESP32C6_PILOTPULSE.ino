#include <lvgl.h>
#include <Arduino_GFX_Library.h>
#include "TouchDrvCSTXXX.hpp"

// ===== EEZ / SquareLine Files =====
#include "ui.h"
#include "screens.h"
#include "images.h"
#include "vars.h"
#include "styles.h"
#include "actions.h"

// ================= DISPLAY PINS =================
#define LCD_SCK 1
#define LCD_DIN 2
#define LCD_CS  5
#define LCD_DC  3
#define LCD_RST 4
#define LCD_BL  6

// ================= TOUCH PINS =================
#define I2C_SDA   8
#define I2C_SCL   7
#define TOUCH_IRQ 11

#define GFX_BL LCD_BL

// ================= DISPLAY OBJECT =================
Arduino_DataBus *bus =
  new Arduino_HWSPI(LCD_DC, LCD_CS, LCD_SCK, LCD_DIN);

Arduino_GFX *gfx =
  new Arduino_ST7789(bus, LCD_RST, 0, true,
                     240, 280,
                     0, 20,
                     0, 20);

// ================= TOUCH OBJECT =================
TouchDrvCSTXXX touch;
volatile bool isPressed = false;

// ================= LVGL =================
lv_disp_draw_buf_t draw_buf;
lv_color_t *buf1;
lv_disp_drv_t disp_drv;

// =================================================
// DISPLAY FLUSH
// =================================================
void my_disp_flush(lv_disp_drv_t *disp,
                   const lv_area_t *area,
                   lv_color_t *color_p)
{
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;

#if LV_COLOR_16_SWAP
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1,
                            (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1,
                           (uint16_t *)&color_p->full, w, h);
#endif

  lv_disp_flush_ready(disp);
}

// =================================================
// TOUCH READ
// =================================================
void my_touchpad_read(lv_indev_drv_t * indev,
                      lv_indev_data_t * data)
{
  int16_t x, y;

  if (isPressed)
  {
    isPressed = false;

    if (touch.getPoint(&x, &y, 1))
    {
      data->state = LV_INDEV_STATE_PR;
      data->point.x = x;
      data->point.y = y;
      return;
    }
  }

  data->state = LV_INDEV_STATE_REL;
}

// =================================================
// SETUP
// =================================================
void setup()
{
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);

  pinMode(GFX_BL, OUTPUT);
  digitalWrite(GFX_BL, HIGH);

  // ---- Display ----
  gfx->begin();
  gfx->fillScreen(BLACK);

  // ---- Touch ----
  if (!touch.begin(Wire, CST816_SLAVE_ADDRESS,
                   I2C_SDA, I2C_SCL))
  {
    Serial.println("Touch Failed");
    while (1);
  }

  attachInterrupt(TOUCH_IRQ, []() {
    isPressed = true;
  }, FALLING);

  // ---- LVGL ----
  lv_init();

  buf1 = (lv_color_t *)heap_caps_malloc(
           240 * 80 * sizeof(lv_color_t),
           MALLOC_CAP_INTERNAL);

  lv_disp_draw_buf_init(&draw_buf, buf1, NULL, 240 * 80);

  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = 240;
  disp_drv.ver_res = 280;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  // ---- LOAD UI ----
  ui_init();

  Serial.println("LVGL UI Loaded");
}

// =================================================
// LOOP
// =================================================
void loop()
{
  lv_timer_handler();
  delay(5);
}