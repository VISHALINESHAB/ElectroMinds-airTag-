#include "images.h"

const ext_img_desc_t images[2] = {
    { "flight", &img_flight },
    { "wifi", &img_wifi },
};
